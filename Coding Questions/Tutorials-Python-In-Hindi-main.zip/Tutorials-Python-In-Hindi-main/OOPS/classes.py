# Classes
# constructors, attributes,methods

# Classes--Real world Entity or object
#attributes--properties of the class
#methods--actions of the class

class Car:
    pass

car1= Car()
car2= Car()

car1.windows=4
car1.tyres=4
car1.engine="diesel"

car2.windows=6
car2.tyres=6
car2.engine="petrol"

#print(car1.engine)
#print(car2.engine)

print(dir(car1))




